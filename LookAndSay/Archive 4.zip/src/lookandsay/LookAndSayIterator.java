package lookandsay;

import java.math.BigInteger;
import java.util.NoSuchElementException;

public class LookAndSayIterator implements RIterator<BigInteger> {
  private BigInteger value;
  private BigInteger max;
  private int seed;
  private boolean hasNext;
  private static final BigInteger maxDefault = new BigInteger("9".repeat(100));
  private static final BigInteger seedDefault = new BigInteger("1");

  /**
   * Constructor for initializing with both variables of our choice.
   * 
   * @param seed the number at which the sequence must begin.
   * @param max  the maximum value.
   */
  public LookAndSayIterator(BigInteger seed, BigInteger max) {
    validateSeed(seed, max);
    value = seed;
    this.max = max;
    hasNext = false;
  }

  /**
   * constructor for initializing with only seed.
   * 
   * @param seed the number at which the sequence must begin.
   */
  public LookAndSayIterator(BigInteger seed) {
    this(seed, maxDefault);
  }

  /**
   * Default Constructor for using default values mentioned above.
   */
  public LookAndSayIterator() {
    this(seedDefault, maxDefault);
  }

  /**
   * Checking if the seed is greater than max or It contains any zero or if it is
   * negative
   * 
   * @param seed the number at which the sequence must begin.
   * @param max  the maximum value.
   */
  private void validateSeed(BigInteger seed, BigInteger max) {
    if (seed.compareTo(max) >= 0 || seed.compareTo(new BigInteger("0")) <= 0
        || seed.toString().indexOf('0') != -1) {
      throw new IllegalArgumentException("The seed is not valid" + seed.toString());
    }
  }

  @Override
  public boolean hasNext() {
    if (!hasNext) {
      return true;
    }
    return calculateNext(value).compareTo(max) < 0;
  }

  /**
   * Helper method for calculating the next item in sequence.
   * 
   * @param seedValue the seed that is passed.
   * @return the next BigInteger in the sequence.
   */
  public BigInteger calculateNext(BigInteger seedValue) {
    String svString = seedValue.toString();
    String next = "";
    for (int i = 0; i < svString.length();) {
      char digit = svString.charAt(i);
      int count = 1;
      while (i + count < svString.length() && svString.charAt(i + count) == digit) {
        count++;
      }
      next = next + "" + digit + count;
      i = i + count;
    }
    return new BigInteger(next.toString());
  }

  @Override
  public BigInteger next() {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    if (hasNext) {
      value = calculateNext(value);
    } else {
      hasNext = true;
    }
    return value;
  }

  @Override
  public BigInteger previous() throws NoSuchElementException {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public boolean hasPrevious() {
    return true;
  }

}
