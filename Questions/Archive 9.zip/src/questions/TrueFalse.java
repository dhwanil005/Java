package questions;

import java.util.ArrayList;

public class TrueFalse implements Question {
  private final String question;
  private final String correctAnswer;
  private String option1 = "True";
  private String option2 = "False";
  public TrueFalse(String question, String correctAnswer,String option1, String option2) {
    this.question = question;
    this.correctAnswer = correctAnswer;
    this.option1 = option1;
    this.option2 = option2;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof TrueFalse) {
      return this.question.compareTo(o.getText());

    } else if (o instanceof MultipleChoice) {
      return -1;

    } else if (o instanceof MultipleSelect) {
      return -1;
    } else {
      return -1;
    }
  }

  @Override
  public String answer(String answer) {
    if (answer(option1) == this.correctAnswer || answer(option2) == this.correctAnswer ) {
      return CORRECT;
    } else {
      return INCORRECT;
    }
  }

  @Override
  public String getText() {
    return this.question;
  }

}
