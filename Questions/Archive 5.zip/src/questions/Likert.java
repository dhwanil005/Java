package questions;

public class Likert implements Question {
  private final String question;

  public Likert(String question) {
    this.question = question;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof TrueFalse) {
      return 1;

    } else if (o instanceof MultipleChoice) {
      return 1;

    } else if (o instanceof MultipleSelect) {
      return 1;
    } else {
      return this.question.compareTo(o.getText());
    }

  }

  @Override
  public String answer(String answer) {
    if (answer == "1" || answer == "2" || answer == "3" || answer == "4" || answer == "5") {
      return CORRECT;
    } else {
      return INCORRECT;
    }
  }

  @Override
  public String getText() {

    return this.question;
  }

}
