package questions;

public class Likert implements Question {
  private final String question;

  public Likert(String question) {
    this.question = question;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof Tf) {
      return 1;

    } else if (o instanceof Mcq) {
      return 1;

    } else if (o instanceof Msq) {
      return 1;
    } else {
      return this.question.compareTo(o.getText());
    }

  }

  @Override
  public String answer(String answer) {
    return CORRECT;
  }

  @Override
  public String getText() {

    return this.question;
  }

}
