package questions;

import java.util.ArrayList;

public class Mcq implements Question {
  private final String question;
  private String correctAnswer;
  private final ArrayList<String> options;

  public Mcq(String question, String correctAnswer, String... options) {
    this.question = question;
    this.correctAnswer = correctAnswer;
    this.options = new ArrayList<String>();
    for (int i = 0; i < options.length; i++) {
      this.options.add(options[i]);
    }

  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof Tf) {
      return 1;

    } else if (o instanceof Mcq) {
      return this.question.compareTo(o.getText());

    } else if (o instanceof Msq) {
      return -1;
    } else {
      return -1;
    }
  }

  @Override
  public String answer(String answer) {
    if (this.correctAnswer == answer)
      return CORRECT;
    else {
      return INCORRECT;
    }
  }

  @Override
  public String getText() {
    return this.question;
  }

}
